/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapp;
import java.util.Scanner;
/**
 *
 * @author wilson_miller
 */
public class ECommerceApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        bannerPrinter(); // Prints out the banner
        String productsCatalog = productsBuilder(); // Build the products catalog
        boolean doesExist = getOrder(productsCatalog);// Get users order, does product exist
        if (doesExist) // Product is found
        {
            double price = getPrice(); // Calulate price
            double tax = getTax(price); // Calulate tax
            double total = getTotal(price, tax); // Calulate total
            printTotal(total); // Print total
        }
        else { // Product does not exist
        System.out.println("Product is not found.");    
        }
        
    }
    
    public static void bannerPrinter() {
        // Defines method to create banner message
        System.out.println("************************************************");
        System.out.println("====== Welcome to Wilson's eCommerce app! ======");
        System.out.println("************************************************");
        System.out.println();
    }
    public static String productsBuilder() {
        // Adds three items to productCatalog (String)
        String productsCatalog = "Desk      Table     Pen       ";
        return productsCatalog;
        
    }
    public static boolean getOrder(String productsCatalog) {
        boolean hasProduct = true; // Use charcounter example
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter a product you wish to order: ");
        String userProductInput = scnr.nextLine();
        // Check to make sure product is available
        if (productsBuilder().toLowerCase().contains(userProductInput.toLowerCase())) {
            // Sets hasProduct to true if item available
            hasProduct = true;
        }
        else {
            // Sets hasProduct to false if item unavailable
            hasProduct = false;
        }
        return hasProduct;
    }
    public static double getPrice() {
        // Random function will be on the final!
        double price = 0;
        // Generate random number between 1 and 100
        price = (int) (Math.random() * ((100 - 1) + 1)) + 1;
        return price;
    }
    public static double getTax(double price) {
        double tax = 0; 
        // Calulate tax a 10%
        tax = price * 0.10;
        return tax;
    }
    public static double getTotal(double price, double tax) {
        double total = 0;
        // Sum of price and tax
        total = price + tax;
        return total;
    }
    public static void printTotal(double total) {
        // System out print
        System.out.printf("Your total is $%.2f ", total); // Generate the total
    
    }
}
